import scrapy
import loginform
from loginform import fill_login_form
import requests
import time
from bs4 import BeautifulSoup

class LoginSpider2(scrapy.Spider):
    name = 'LoginSpider2'

    start_urls = []

    login_url = 'http://jsh.christianscience.com/user/login'

    login_user = 'us@cas.au.dk'
    login_password = 'berliN21'
    testcounter = 0

    def start_requests(self):
        # let's start by sending a first request to login page
		counter = 0
		
		for i in xrange(1, 6047):
			urllist = "http://jsh.christianscience.com/content/search/(offset)/" + `counter` + "?SearchText=&Publication%5B%5D=Journal&Publication%5B%5D=Sentinel&Type=testimony&PrimarySort=3&SearchPageLimit=2"   
			counter = counter + 10
			#self.log("adding: " + urllist + " to START URLS")
			self.start_urls.append(urllist)
		yield scrapy.Request(self.login_url, self.parse_login)

    def parse_login(self, response):
        # got the login page, let's fill the login form...
        data, url, method = fill_login_form(response.url, response.body,
                                            self.login_user, self.login_password)

        # ... and send a request with our login data
        return scrapy.FormRequest(url, formdata=dict(data),
                           method=method, callback=self.start_crawl, dont_filter=True)

    def start_crawl(self, response):
        # OK, we're in, let's start crawling the protected pages
        self.log("Start crawling protected pages")
        for url in self.start_urls:
			#self.log("trying to parse " + url)
			yield scrapy.Request(url)

    def parse(self, response):
		self.log("parsing: " + response.url)
		selections = response.xpath('//*[contains(concat( " ", @class, " " ), concat( " ", "line-title", " " ))]//a/@href').extract()
		for sel in selections:
			yield scrapy.Request(url=sel, callback=self.parseTestimonial)
        # do stuff with the logged in response
		#with open("responsenew.htm", 'wb') as f:
		#	f.write(response.body)

    def parseTestimonial(self, response):
		self.log("parsing TESTIMONIAL: " + response.url)
		selections2 = response.xpath('//*[contains(concat( " ", @class, " " ), concat( " ", "source-attribution", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "byline", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "pagetitle", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "attribute-body", " " ))]//p').extract()
		#selections2 = response.xpath('//*[contains(concat( " ", @class, " " ), concat( " ", "full-view-article", " " ))]//p').extract()
		#selections2 = response.css('.attribute-body').extract()
		#str(int(round(time.time() * 1000))
		text = ""
		databasefilename = "database.txt"
		
		with open(databasefilename, 'ab') as f:
			output = ""
			for sel in selections2:
				soup = BeautifulSoup(sel, 'html.parser')
				stripped_text = soup.get_text().strip('\t').strip()
				output = output + stripped_text + '\t'
			f.write((response.url + '\t' + output + '\n').encode("UTF-8"))
		return
	